#!/bin/bash
DATE=`date`
echo "$DATE : Clearing {{ system_scripts_backup_days }} days old backup file "
find {{ system_scripts_backup_location }} -type f ! -name '*.sh' -mtime +{{ system_scripts_backup_days }} -exec rm -r {} \;
echo "$DATE : Clearnig {{ system_scripts_backup_days }} days old directory if present"
find {{ system_scripts_backup_location }} -type d ! -name '*.sh' -mtime +{{ system_scripts_backup_days }} -exec rm -r {} \;
