#!/bin/bash
PWD="{{ system_scripts_backup_location }}"
{% raw %}
source $PWD/variable.sh
sshpass -p "$PROD_PLATFORM_PROXY_PASSWORD" ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa.pub $PROD_PLATFORM_PROXY_USER@$PROD_PLATFORM_PROXY_IP
sshpass -p "$PROD_INTERFACE_PASSWORD" ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa.pub $PROD_INTERFACE_USER@$PROD_INTERFACE_IP
sshpass -p "$PROD_PLATFORM_CORE_PASSWORD" ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa.pub $PROD_PLATFORM_CORE_USER@$PROD_PLATFORM_CORE_IP
sshpass -p "$PROD_PLATFORM_DB_PASSWORD" ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa.pub $PROD_PLATFORM_DB_USER@$PROD_PLATFORM_DB_IP
sshpass -p "$PROD_CORE_PASSWORD" ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa.pub $PROD_CORE_USER@$PROD_CORE_IP
sshpass -p "$PROD_METRICS_PASSWORD" ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa.pub $PROD_METRICS_USER@$PROD_METRICS_IP
sshpass -p "$PROD_TOWER_PASSWORD" ssh-copy-id -o StrictHostKeyChecking=no -i ~/.ssh/id_rsa.pub $PROD_TOWER_USER@$PROD_TOWER_IP
{% endraw %}