#!/bin/bash
PWD="{{ system_scripts_backup_location }}"
{% raw %}
source $PWD/variable.sh
DIRECTORY=$(date +"%d-%m-%Y-%R")
echo ""
echo "###############################################"
echo "Making directory : $DIRECTORY"
echo "###############################################"
echo ""
mkdir -p $PWD/"$DIRECTORY"_BACKUP/{core_backup/{logs,mnesia_backup},interface_backup/{logs,postgres},platform_backup/{platform_core_logs,platform_db_logs,db_backup},metric/{logs,influx,metabase,grafana},tower/logs,configs/{core,platform_db,platform_core,interface}}
sudo find $PWD/"$DIRECTORY"_BACKUP -exec chown $PROD_METRICS_USER:$PROD_METRICS_USER {} \;
#Saving core logs and core config
echo ""
echo "###############################################"
echo "Saving core logs and core config"
echo "###############################################"
echo ""
sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP "mkdir /tmp/'$DIRECTORY' && find /var/log/butler_server/log/ -type f -mtime -1 | xargs tar -czvPf  /tmp/'$DIRECTORY'/core_all_logs.tar.gz"
sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP "cp /etc/butler_server/sys.local.config /tmp/'$DIRECTORY' && cp /etc/butler_server/sys.config /tmp/'$DIRECTORY' && cp /etc/postgresql/9.6/main/postgresql.conf  /tmp/'$DIRECTORY' && sudo su -c 'cp /etc/postgresql/9.6/main/pg_hba.conf /tmp/"$DIRECTORY"'"
sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP 'sudo /opt/butler_server/bin/butler_server rpcterms mnesia backup \"/tmp/mnesia_backup\".'
file_path=`curl -X POST  http://$PROD_CORE_IP:8181/api/mhs/collect_debugging_data -H 'Accept: application/json' -H 'Content-Type: application/json' | awk '{print $3}'`
echo "$file_path"
#Saving platform logs and config
echo ""
echo "###############################################"
echo "Saving platform core logs and config"
echo "###############################################"
echo ""
sshpass -p "$PROD_PLATFORM_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_PLATFORM_CORE_USER@$PROD_PLATFORM_CORE_IP "mkdir /tmp/'$DIRECTORY' && sudo su -c 'find /opt/tomcat/logs/ -type f -mtime -1 | xargs tar -czvPf  /tmp/"$DIRECTORY"/platform_core_logs.tar.gz'"
sshpass -p "$PROD_PLATFORM_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_PLATFORM_CORE_USER@$PROD_PLATFORM_CORE_IP "sudo su -c 'cp /opt/tomcat/bin/setenv.sh /tmp/"$DIRECTORY"' && cp /etc/systemd/system/tomcat.service /tmp/'$DIRECTORY' && sudo su -c 'cp /opt/tomcat/conf/server.xml /tmp/"$DIRECTORY"' && sudo su -c 'consul kv export > /tmp/"$DIRECTORY"/consul_backup_hexa.txt'"

#Saving platform DB config
echo ""
echo "###############################################"
echo "Saving platform DB logs and config"
echo "###############################################"
echo ""
sshpass -p "$PROD_PLATFORM_DB_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_PLATFORM_DB_USER@$PROD_PLATFORM_DB_IP "mkdir /tmp/'$DIRECTORY' && sudo su -c 'find /var/log/ -type f ! -name 'lastlog' ! -name 'sudo.log' -mtime -1 | xargs tar -czvPf  /tmp/"$DIRECTORY"/platform_db_logs.tar.gz'"
sshpass -p "$PROD_PLATFORM_DB_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_PLATFORM_DB_USER@$PROD_PLATFORM_DB_IP "cp /etc/postgresql/9.6/main/postgresql.conf /tmp/'$DIRECTORY' && sudo su -c 'cp /etc/postgresql/9.6/main/pg_hba.conf /tmp/"$DIRECTORY"'"

#Saving Interface logs and interface config
echo ""
echo "###############################################"
echo "Saving interface logs and config"
echo "###############################################"
echo ""
sshpass -p "$PROD_INTERFACE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_INTERFACE_USER@$PROD_INTERFACE_IP "mkdir /tmp/'$DIRECTORY' && sudo su -c 'find /var/log/ -type f ! -name 'lastlog' ! -name 'sudo.log' -mtime -1 | xargs tar -czvPf  /tmp/"$DIRECTORY"/interface_logs.tar.gz'"
sshpass -p "$PROD_INTERFACE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_INTERFACE_USER@$PROD_INTERFACE_IP "cp /opt/butler_interface/butler_interface/config.py /tmp/'$DIRECTORY' && cp /opt/butler_cockpit/static/js/main.*.js /tmp/'$DIRECTORY' && cp /opt/butler_ui/assets/js/main.js /tmp/'$DIRECTORY' && cp /opt/butler_bff/.env /tmp/'$DIRECTORY' && cp /opt/butler_bff/tabconfig.env /tmp/'$DIRECTORY' && cp /etc/supervisor/conf.d/butler_interface.conf /tmp/'$DIRECTORY'/butler_interface_supervisor.conf &&  cp /etc/nginx/conf.d/butler_interface.conf /tmp/'$DIRECTORY'/butler_interface_nginx.conf && cp /etc/postgresql/9.6/main/postgresql.conf  /tmp/'$DIRECTORY' && sudo su -c 'cp /etc/postgresql/9.6/main/pg_hba.conf /tmp/"$DIRECTORY"'"

#Saving Tower logs 
echo ""
echo "###############################################"
echo "Saving Tower logs"
echo "###############################################"
echo ""
sshpass -p "$PROD_TOWER_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_TOWER_USER@$PROD_TOWER_IP "sudo su -c 'mkdir /tmp/"$DIRECTORY"' && sudo su -c 'find /var/log/ -type f ! -name 'lastlog' ! -name 'sudo.log' -mtime -1 | xargs tar -czvPf  /tmp/"$DIRECTORY"/tower_logs.tar.gz'"

#Saving Metric logs 
echo ""
echo "###############################################"
echo "Saving Metric logs"
echo "###############################################"
echo ""
sudo su -c "find /var/log/ -type f ! -name 'lastlog' ! -name 'sudo.log' -mtime -1 | xargs tar -czvPf  $PWD/"$DIRECTORY"_BACKUP/metric/logs/metric_logs.tar.gz"

#Grafana Backup
echo ""
echo "###############################################"
echo "Saving Grafana backup"
echo "###############################################"
echo ""
grafana_volume_path=`sudo docker volume inspect metrics-docker_grafana --format='{{ (index .Mountpoint) }}'`
sudo cp ${grafana_volume_path}/grafana.db $PWD/"$DIRECTORY"_BACKUP/metric/grafana/grafana.db

echo ""
echo "###############################################"
echo "Saving Metabase backup"
echo "###############################################"
echo ""
sudo cp -r /opt/metabase-docker/metabase-data $PWD/"$DIRECTORY"_BACKUP/metric/metabase/metabase-data

echo ""
echo "###############################################"
echo "Changing permission to gor for all Server"
echo "###############################################"
echo ""
sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP "sudo su -c 'find /tmp/"$DIRECTORY" -exec chown $PROD_CORE_USER:$PROD_CORE_USER {} \;'"
sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP "sudo su -c 'find /tmp/mnesia_backup -exec chown $PROD_CORE_USER:$PROD_CORE_USER {} \;'"
sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP "sudo su -c 'find $file_path -exec chown $PROD_CORE_USER:$PROD_CORE_USER {} \;'"
sshpass -p "$PROD_PLATFORM_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_PLATFORM_CORE_USER@$PROD_PLATFORM_CORE_IP "sudo su -c 'find /tmp/"$DIRECTORY" -exec chown $PROD_PLATFORM_CORE_USER:$PROD_PLATFORM_CORE_USER {} \;'"
sshpass -p "$PROD_PLATFORM_DB_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_PLATFORM_DB_USER@$PROD_PLATFORM_DB_IP "sudo su -c 'find /tmp/"$DIRECTORY" -exec chown $PROD_PLATFORM_DB_USER:$PROD_PLATFORM_DB_USER {} \;'"
sshpass -p "$PROD_INTERFACE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_INTERFACE_USER@$PROD_INTERFACE_IP "sudo su -c 'find /tmp/"$DIRECTORY" -exec chown $PROD_INTERFACE_USER:$PROD_INTERFACE_USER {} \;'"
sshpass -p "$PROD_TOWER_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_TOWER_USER@$PROD_TOWER_IP "sudo su -c 'find /tmp/"$DIRECTORY" -exec chown $PROD_TOWER_USER:$PROD_TOWER_USER {} \;'"


#Copy file from core server
echo ""
echo "###############################################"
echo "Copy file from Core server"
echo "###############################################"
echo ""
scp -r $PROD_CORE_USER@$PROD_CORE_IP:/tmp/"$DIRECTORY" /tmp
scp -r $PROD_CORE_USER@$PROD_CORE_IP:/tmp/mnesia_backup $PWD/"$DIRECTORY"_BACKUP/core_backup/mnesia_backup
scp $PROD_CORE_USER@$PROD_CORE_IP:$file_path $PWD/"$DIRECTORY"_BACKUP/core_backup/logs

sudo mv /tmp/"$DIRECTORY"/core_all_logs.tar.gz $PWD/"$DIRECTORY"_BACKUP/core_backup/logs
sudo mv /tmp/"$DIRECTORY"/sys* $PWD/"$DIRECTORY"_BACKUP/configs/core
sudo mv /tmp/"$DIRECTORY"/*.conf $PWD/"$DIRECTORY"_BACKUP/configs/core
sudo rm -r /tmp/"$DIRECTORY"

#Copy from platform Core
echo ""
echo "###############################################"
echo "Copy file from Platform core server"
echo "###############################################"
echo ""
scp -r $PROD_PLATFORM_CORE_USER@$PROD_PLATFORM_CORE_IP:/tmp/"$DIRECTORY" /tmp
sudo mv /tmp/"$DIRECTORY"/platform_core_logs.tar.gz $PWD/"$DIRECTORY"_BACKUP/platform_backup/platform_core_logs
sudo mv /tmp/"$DIRECTORY"/setenv.sh $PWD/"$DIRECTORY"_BACKUP/configs/platform_core
sudo mv /tmp/"$DIRECTORY"/tomcat.service $PWD/"$DIRECTORY"_BACKUP/configs/platform_core
sudo mv /tmp/"$DIRECTORY"/server.xml $PWD/"$DIRECTORY"_BACKUP/configs/platform_core
sudo mv /tmp/"$DIRECTORY"/consul_backup_hexa.txt $PWD/"$DIRECTORY"_BACKUP/configs/platform_core
sudo rm -r /tmp/"$DIRECTORY"

#Copy from platform DB
echo ""
echo "###############################################"
echo "Copy file from Platform DB server"
echo "###############################################"
echo ""
scp -r $PROD_PLATFORM_DB_USER@$PROD_PLATFORM_DB_IP:/tmp/"$DIRECTORY" /tmp
sudo mv /tmp/"$DIRECTORY"/platform_db_logs.tar.gz $PWD/"$DIRECTORY"_BACKUP/platform_backup/platform_db_logs
sudo mv /tmp/"$DIRECTORY"/*.conf $PWD/"$DIRECTORY"_BACKUP/configs/platform_db
sudo rm -r /tmp/"$DIRECTORY"

#Copy from Interface Core
echo ""
echo "###############################################"
echo "Copy file from Interface server"
echo "###############################################"
echo ""
scp -r $PROD_INTERFACE_USER@$PROD_INTERFACE_IP:/tmp/"$DIRECTORY" /tmp
sudo mv /tmp/"$DIRECTORY"/interface_logs.tar.gz $PWD/"$DIRECTORY"_BACKUP/interface_backup/logs
sudo mv /tmp/"$DIRECTORY"/config.py $PWD/"$DIRECTORY"_BACKUP/configs/interface
sudo mv /tmp/"$DIRECTORY"/main.*.js $PWD/"$DIRECTORY"_BACKUP/configs/interface
sudo mv /tmp/"$DIRECTORY"/main.js $PWD/"$DIRECTORY"_BACKUP/configs/interface
sudo mv /tmp/"$DIRECTORY"/.env $PWD/"$DIRECTORY"_BACKUP/configs/interface
sudo mv /tmp/"$DIRECTORY"/tabconfig.env $PWD/"$DIRECTORY"_BACKUP/configs/interface
sudo mv /tmp/"$DIRECTORY"/*.conf $PWD/"$DIRECTORY"_BACKUP/configs/interface
sudo rm -r /tmp/"$DIRECTORY"

#Copy from Tower VM
echo ""
echo "###############################################"
echo "Copy file from Tower server"
echo "###############################################"
echo ""
scp -r $PROD_TOWER_USER@$PROD_TOWER_IP:/tmp/"$DIRECTORY" /tmp
sudo mv /tmp/"$DIRECTORY"/tower_logs.tar.gz $PWD/"$DIRECTORY"_BACKUP/tower/logs
sudo rm -r /tmp/"$DIRECTORY"


#Delete directory from remote server
echo ""
echo "###############################################"
echo "Delete file from all server"
echo "###############################################"
echo ""

sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP "sudo su -c 'rm -r /tmp/'$DIRECTORY''"
sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP "sudo su -c 'rm -r /tmp/mnesia_backup'"
sshpass -p "$PROD_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_CORE_USER@$PROD_CORE_IP "sudo su -c 'rm $file_path'"
sshpass -p "$PROD_PLATFORM_CORE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_PLATFORM_CORE_USER@$PROD_PLATFORM_CORE_IP "sudo su -c 'rm -r /tmp/'$DIRECTORY''"
sshpass -p "$PROD_PLATFORM_DB_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_PLATFORM_DB_USER@$PROD_PLATFORM_DB_IP "sudo su -c 'rm -r /tmp/'$DIRECTORY''"
sshpass -p "$PROD_INTERFACE_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_INTERFACE_USER@$PROD_INTERFACE_IP "sudo su -c 'rm -r /tmp/'$DIRECTORY''"
sshpass -p "$PROD_TOWER_PASSWORD" ssh -o StrictHostKeyChecking=no -t $PROD_TOWER_USER@$PROD_TOWER_IP "sudo su -c 'rm -r /tmp/'$DIRECTORY''"
{% endraw %}

